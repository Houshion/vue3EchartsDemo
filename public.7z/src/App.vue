<template>
  <el-config-provider namespace="ep" :locale="zhCn">
    <BaseHeader />
    <div class="flex main-container">
      <BaseSide />
      <div w="full" py="0" h="full">
        <Home></Home>
        <!-- <Logos my="4" /> -->
        <!-- <HelloWorld msg="Hello Vue 3 + Element Plus + Vite" /> -->
      </div>
    </div>
  </el-config-provider>
</template>
<script setup lang="ts">
import zhCn from "element-plus/dist/locale/zh-cn.mjs";
</script>
<style>
#app {
  text-align: center;
  color: var(--ep-text-color-primary);
}

.main-container {
  height: calc(100vh - var(--ep-menu-item-height) - 3px);
}
.flex {
  display: flex;
}
</style>
